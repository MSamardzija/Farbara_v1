var date = new Date();
var year = date.getFullYear();
document.getElementById("year").innerHTML = year;
